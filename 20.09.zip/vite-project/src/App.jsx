import { useState } from "react";
import "./App.scss";

function App() {
  const str1 = "text1";
  const str2 = "text1";
  const name = "user";
  const age = "30";
  const arr = [1, 2, 3, 4, 5];
  const obj = { name: "john", surname: "smit" };
  const attr = "block";
  const li1 = <li>text1</li>;
	const li2 = <li>text2</li>;
	const li3 = <li>text3</li>;
  const items = <><li>text1</li><li>text2</li><li>text3</li></>;
  return (
    <>
      <div id={attr}>

        {/* 7 */}
        <p className="text_1">kappa</p>
        <p className="text_2">kappa</p>


        {/* 8 */}
        <ul>
          <li>1</li>
          <li>2</li>
          <li>3</li>
          <li>4</li>
          <li>5</li>
          <li>6</li>
          <li>7</li>
          <li>8</li>
          <li>9</li>
          <li>10</li>
        </ul>


        {/* 10 */}
        <ul>
          <li>text1</li>
          <li>text2</li>
          <li>text3</li>
        </ul>
        <ul>
          <li>text1</li>
          <li>text2</li>
          <li>text3</li>
        </ul>
        <ul>
          <li>text1</li>
          <li>text2</li>
          <li>text3</li>
        </ul>


        {/* 12 */}
        <input />
        <input />
        <input />


        {/* 13 */}
        <p>{str1}</p>
        <p>{str2}</p>


        {/* 14 */}
        <p>name:{name}</p>
        <p> age:{age}</p>


        {/* 15 */}
        <ul>
          <li>{arr[0]}</li>
          <li>{arr[1]}</li>
          <li>{arr[2]}</li>
          <li>{arr[3]}</li>
          <li>{arr[4]}</li>
        </ul>


        {/* 16 */}
        <p>
          name:<span>{obj.name}</span> <br /> surname:<span>{obj.surname}</span>
        </p>


        {/* 19 */}
        <ul>
          <li>{li1}</li>
          <li>{li2}</li>
          <li>{li3}</li>
        </ul>


        {/* 20 */}
        <p>{items}</p>
      </div>
    </>
  );
}

export default App;
